# CSS - Basic Layout - NPR The Salt

### The Mockup
![mockup](./mockups/grid-flexbox-demo.png)


### Instructions


### Designer Specs

```
blue  : #bff
yellow : #ff9
```
